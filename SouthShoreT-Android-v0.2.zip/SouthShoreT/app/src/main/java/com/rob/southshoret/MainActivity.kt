package com.rob.southshoret

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rob.southshoret.data.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BoardApp() }
    }
}

@Composable
fun BoardApp(repo: MbtaRepository = remember { MbtaRepository() }) {
    var boards by remember { mutableStateOf<List<StationBoard>>(emptyList()) }
    var alerts by remember { mutableStateOf<List<AlertItem>>(emptyList()) }
    var alertIndex by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            var failed = false
            try { boards = repo.loadBoards() } catch (_: Exception) { failed = true }
            try { alerts = repo.loadAllAlerts() } catch (_: Exception) { failed = true }
            error = if (failed) "MBTA data unavailable" else null
            delay(20_000)
        }
    }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1_000) } }
    LaunchedEffect(alerts.size) { while (alerts.isNotEmpty()) { delay(9_000); alertIndex = (alertIndex + 1) % alerts.size } }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            val names = listOf("Braintree", "Quincy Adams", "Quincy Center", "Weymouth Landing", "East Weymouth", "Park Street")
            names.forEach { name ->
                StationColumn(boards.firstOrNull { it.name == name } ?: StationBoard(name, emptyList()), Modifier.weight(1f).fillMaxHeight())
            }
        }
        Footer(now, alerts.getOrNull(alertIndex)?.header, error)
    }
}

@Composable
private fun StationColumn(board: StationBoard, modifier: Modifier) {
    Column(modifier.padding(horizontal = 4.dp).background(Color.Black)) {
        Text(board.name.uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, modifier = Modifier.padding(8.dp))
        val grouped = board.departures.groupBy { it.mode }
        val modes = if (board.name == "Park Street") listOf(Mode.RED, Mode.GREEN, Mode.BUS) else listOf(Mode.RED, Mode.BUS, Mode.COMMUTER)
        modes.forEach { mode -> ModeBlock(mode, grouped[mode].orEmpty().take(3), Modifier.weight(1f)) }
    }
}

@Composable
private fun ModeBlock(mode: Mode, deps: List<Departure>, modifier: Modifier) {
    val (label, color) = when (mode) {
        Mode.RED -> "RED LINE" to Color(0xFFDA291C)
        Mode.GREEN -> "GREEN LINE" to Color(0xFF00843D)
        Mode.BUS -> "BUS" to Color(0xFFFFC72C)
        Mode.COMMUTER -> "COMMUTER RAIL" to Color(0xFF80276C)
    }
    Column(modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Box(Modifier.fillMaxWidth().background(color).padding(horizontal = 7.dp, vertical = 4.dp)) {
            Text(label, color = if (mode == Mode.BUS) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        if (deps.isEmpty()) Text("—", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(8.dp))
        deps.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (mode == Mode.BUS) "${d.route}  ${d.destination}" else d.destination, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text(if (d.minutes <= 0) "ARR" else "${d.minutes} MIN", color = Color(0xFFFFD100), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Footer(now: LocalDateTime, alert: String?, error: String?) {
    val date = now.format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy"))
    val time = now.format(DateTimeFormatter.ofPattern("h:mm:ss a"))
    Row(Modifier.fillMaxWidth().height(44.dp).background(Color(0xFF171717)), verticalAlignment = Alignment.CenterVertically) {
        Text("  $date   |   $time  ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Box(Modifier.background(Color(0xFFFFC72C)).padding(horizontal = 10.dp, vertical = 5.dp)) { Text("SERVICE ALERTS", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp) }
        Text("  ${error?.let { "DATA TEMPORARILY UNAVAILABLE" } ?: alert ?: "NO CURRENT SERVICE ALERTS"}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
    }
}
