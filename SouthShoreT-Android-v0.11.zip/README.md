# South Shore T Board — Android prototype

A landscape, display-only MBTA arrivals board for Braintree, Quincy Adams, Quincy Center, Weymouth Landing, East Weymouth, and Park Street.

## Features in this first build
- Kotlin + Jetpack Compose
- Immersive landscape display
- Live MBTA V3 prediction queries
- Red Line, bus, Commuter Rail, and Park Street Green Line sections
- Systemwide MBTA alert rotation
- Automatic 20-second data refresh
- Live clock
- No menus, dropdowns, or routine user input

## Open in Android Studio
Open the `SouthShoreT` folder and let Gradle sync. Run on an Android 8.0+ device/tablet or emulator in landscape.

The MBTA API permits experimentation without a key. For sustained use, request an MBTA V3 API key and put it into the `MBTA_API_KEY` BuildConfig field in `app/build.gradle.kts`.

## Prototype note
Stop IDs and route/display behavior should be verified against live MBTA responses during device testing. This is v0.1: the next pass should refine exact station-sign typography/spacing, prediction grouping/direction handling, commuter-rail track/status presentation, and ticker animation.
