package com.rob.southshoret.data

import com.rob.southshoret.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.time.Duration
import java.time.OffsetDateTime

data class Departure(val route: String, val destination: String, val minutes: Int, val mode: Mode)
data class StationBoard(val name: String, val departures: List<Departure>)
data class AlertItem(val header: String)
enum class Mode { RED, GREEN, BUS, COMMUTER }

class MbtaRepository {
    private val client = OkHttpClient()
    private val base = "https://api-v3.mbta.com"

    private val stations = linkedMapOf(
        "East Weymouth" to "place-GRB-0146",
        "Weymouth Landing" to "place-GRB-0118",
        "Braintree" to "place-brntn",
        "Quincy Adams" to "place-qamnl",
        "Quincy Center" to "place-qnctr",
        "Park Street" to "place-pktrm"
    )

    suspend fun loadBoards(): List<StationBoard> = withContext(Dispatchers.IO) {
        val landingBus = weymouthLanding225Predictions()
        stations.map { (name, stopId) ->
            // Query child/platform stops as well as the parent station. This is important for
            // Green Line and Commuter Rail stations where predictions may live on platforms.
            val baseDepartures = when (name) {
                // Query the MBTA parent station directly. The predictions endpoint expands
                // parent stations to their boarding platforms; route filters keep each mode exact.
                "East Weymouth" -> greenbushDepartures("GRB-0146-S")
                "Weymouth Landing" -> greenbushDepartures("GRB-0118-S")
                "Park Street" -> {
                    val red = predictionsForStation("place-pktrm").filter { it.mode == Mode.RED }
                    val green = parkStreetGreenDepartures()
                    red + green
                }
                else -> predictionsForStation(stopId)
            }
            val departures = when (name) {
                "Weymouth Landing" -> baseDepartures + landingBus
                else -> baseDepartures
            }
            StationBoard(name, departures.distinctBy { listOf(it.route, it.destination, it.minutes, it.mode) })
        }
    }

    suspend fun loadAllAlerts(): List<AlertItem> = withContext(Dispatchers.IO) {
        val root = getJson("/alerts")
        val data = root.optJSONArray("data") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until data.length()) {
                val attrs = data.getJSONObject(i).optJSONObject("attributes") ?: continue
                val header = attrs.optString("header").trim()
                if (header.isNotEmpty()) add(AlertItem(header))
            }
        }
    }

    private fun weymouthLanding225Predictions(): List<Departure> {
        val wanted = setOf("Quincy Ave @ Weymouth Landing", "Quincy Ave @ Commercial St")
        val stopsRoot = getJson("/stops?filter[route]=225")
        val data = stopsRoot.optJSONArray("data") ?: return emptyList()
        val stopIds = buildList {
            for (i in 0 until data.length()) {
                val stop = data.getJSONObject(i)
                val name = stop.optJSONObject("attributes")?.optString("name").orEmpty()
                if (name in wanted) add(stop.optString("id"))
            }
        }.filter { it.isNotBlank() }.distinct()

        return stopIds.flatMap { predictionsFor(it) }
            .filter { it.mode == Mode.BUS && it.route == "225" }
            .distinctBy { Triple(it.destination, it.minutes, it.route) }
            .sortedBy { it.minutes }
            .take(3)
    }



    private fun greenbushDepartures(platformId: String): List<Departure> {
        // Prefer real-time predictions. Commuter Rail predictions can legitimately be absent
        // well before a train, so fall back to the published schedule for this exact platform.
        val live = runCatching { predictionsFor(platformId, "CR-Greenbush") }
            .getOrDefault(emptyList())
            .filter { it.mode == Mode.COMMUTER }
            .sortedBy { it.minutes }
        if (live.isNotEmpty()) return live.take(3)

        return runCatching { schedulesFor(platformId, "CR-Greenbush") }
            .getOrDefault(emptyList())
            .filter { it.mode == Mode.COMMUTER }
            .sortedBy { it.minutes }
            .take(3)
    }

    private fun parkStreetGreenDepartures(): List<Departure> {
        // Verified Park Street Green Line boarding locations:
        // 70200 = Government Center/North; 70196-70199 = westbound/terminating platforms.
        val platformIds = listOf("70200", "70196", "70197", "70198", "70199")
        val live = platformIds
            .flatMap { id -> runCatching { predictionsFor(id) }.getOrDefault(emptyList()) }
            .filter { it.mode == Mode.GREEN }
            .distinctBy { listOf(it.route, it.destination, it.minutes) }
            .sortedBy { it.minutes }

        if (live.isNotEmpty()) return live.take(6)

        // Schedule fallback prevents a blank Green Line panel if the prediction feed
        // temporarily has no records for a platform.
        return platformIds
            .flatMap { id -> runCatching { schedulesFor(id) }.getOrDefault(emptyList()) }
            .filter { it.mode == Mode.GREEN }
            .distinctBy { listOf(it.route, it.destination, it.minutes) }
            .sortedBy { it.minutes }
            .take(6)
    }

    private fun predictionsForStops(stopIds: List<String>): List<Departure> =
        stopIds.flatMap { id -> runCatching { predictionsFor(id) }.getOrDefault(emptyList()) }
            .distinctBy { listOf(it.route, it.destination, it.minutes, it.mode) }
            .sortedBy { it.minutes }

    private fun predictionsForStation(parentId: String): List<Departure> {
        val ids = linkedSetOf(parentId)
        runCatching {
            val root = getJson("/stops?filter[parent_station]=$parentId")
            val data = root.optJSONArray("data")
            if (data != null) for (i in 0 until data.length()) {
                data.getJSONObject(i).optString("id").takeIf { it.isNotBlank() }?.let(ids::add)
            }
        }
        return ids.flatMap { predictionsFor(it) }
            .distinctBy { listOf(it.route, it.destination, it.minutes, it.mode) }
            .sortedBy { it.minutes }
    }

    private fun predictionsFor(stopId: String, routeFilter: String? = null): List<Departure> {
        val routePart = routeFilter?.let { "&filter[route]=$it" }.orEmpty()
        val root = getJson("/predictions?filter[stop]=$stopId$routePart&include=route,trip&sort=departure_time")
        val included = root.optJSONArray("included")
        val routeTypes = mutableMapOf<String, Int>()
        val routeDestinations = mutableMapOf<String, List<String>>()
        val tripHeadsigns = mutableMapOf<String, String>()
        if (included != null) for (i in 0 until included.length()) {
            val obj = included.getJSONObject(i)
            when (obj.optString("type")) {
                "route" -> {
                    val attrs = obj.optJSONObject("attributes")
                    routeTypes[obj.getString("id")] = attrs?.optInt("type", -1) ?: -1
                    val dirs = attrs?.optJSONArray("direction_destinations")
                    routeDestinations[obj.getString("id")] = if (dirs == null) emptyList() else
                        (0 until dirs.length()).map { dirs.optString(it) }
                }
                "trip" -> tripHeadsigns[obj.getString("id")] = obj.optJSONObject("attributes")?.optString("headsign").orEmpty()
            }
        }
        val now = OffsetDateTime.now()
        val data = root.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<Departure>()
        for (i in 0 until data.length()) {
            val obj = data.getJSONObject(i)
            val attrs = obj.getJSONObject("attributes")
            val whenText = attrs.optString("departure_time").ifBlank { attrs.optString("arrival_time") }
            if (whenText.isBlank()) continue
            val event = runCatching { OffsetDateTime.parse(whenText) }.getOrNull() ?: continue
            val mins = Duration.between(now, event).toMinutes().coerceAtLeast(0).toInt()
            val rel = obj.getJSONObject("relationships")
            val routeId = rel.getJSONObject("route").optJSONObject("data")?.optString("id").orEmpty()
            val tripId = rel.getJSONObject("trip").optJSONObject("data")?.optString("id").orEmpty()
            val type = routeTypes[routeId] ?: -1
            val directionId = attrs.optInt("direction_id", -1)
            val routeDestination = routeDestinations[routeId]?.getOrNull(directionId).orEmpty()
            val mode = when {
                routeId == "Red" -> Mode.RED
                routeId.startsWith("Green-") -> Mode.GREEN
                type == 3 -> Mode.BUS
                type == 2 -> Mode.COMMUTER
                else -> continue
            }
            val displayRoute = when (routeId) {
                "CR-Greenbush" -> "Greenbush"
                else -> routeId
            }
            val destination = tripHeadsigns[tripId].orEmpty()
                .ifBlank { routeDestination }
                .ifBlank { displayRoute }
            out += Departure(displayRoute, destination, mins, mode)
        }
        return out.take(12)
    }

    private fun schedulesFor(stopId: String, routeFilter: String? = null): List<Departure> {
        val routePart = routeFilter?.let { "&filter[route]=$it" }.orEmpty()
        val root = getJson("/schedules?filter[stop]=$stopId$routePart&include=route,trip")
        val included = root.optJSONArray("included")
        val routeTypes = mutableMapOf<String, Int>()
        val routeDestinations = mutableMapOf<String, List<String>>()
        val tripHeadsigns = mutableMapOf<String, String>()
        if (included != null) for (i in 0 until included.length()) {
            val obj = included.getJSONObject(i)
            when (obj.optString("type")) {
                "route" -> {
                    val routeAttrs = obj.optJSONObject("attributes")
                    routeTypes[obj.getString("id")] = routeAttrs?.optInt("type", -1) ?: -1
                    val dirs = routeAttrs?.optJSONArray("direction_destinations")
                    routeDestinations[obj.getString("id")] = if (dirs == null) emptyList() else
                        (0 until dirs.length()).map { dirs.optString(it) }
                }
                "trip" -> tripHeadsigns[obj.getString("id")] =
                    obj.optJSONObject("attributes")?.optString("headsign").orEmpty()
            }
        }

        val now = OffsetDateTime.now()
        val data = root.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<Departure>()
        for (i in 0 until data.length()) {
            val obj = data.getJSONObject(i)
            val attrs = obj.getJSONObject("attributes")
            val whenText = attrs.optString("departure_time").ifBlank { attrs.optString("arrival_time") }
            if (whenText.isBlank()) continue
            val event = runCatching { OffsetDateTime.parse(whenText) }.getOrNull() ?: continue
            if (event.isBefore(now)) continue
            val mins = Duration.between(now, event).toMinutes().coerceAtLeast(0).toInt()

            val rel = obj.getJSONObject("relationships")
            val routeId = rel.getJSONObject("route").optJSONObject("data")?.optString("id").orEmpty()
            val tripId = rel.getJSONObject("trip").optJSONObject("data")?.optString("id").orEmpty()
            val type = routeTypes[routeId] ?: -1
            val directionId = attrs.optInt("direction_id", -1)
            val routeDestination = routeDestinations[routeId]?.getOrNull(directionId).orEmpty()
            val mode = when {
                routeId == "Red" -> Mode.RED
                routeId.startsWith("Green-") -> Mode.GREEN
                type == 3 -> Mode.BUS
                type == 2 || routeId.startsWith("CR-") -> Mode.COMMUTER
                else -> continue
            }
            val displayRoute = if (routeId == "CR-Greenbush") "Greenbush" else routeId
            out += Departure(
                displayRoute,
                tripHeadsigns[tripId].orEmpty().ifBlank { routeDestination }.ifBlank { displayRoute },
                mins,
                mode
            )
        }
        return out.sortedBy { it.minutes }.take(12)
    }

    private fun getJson(path: String): JSONObject {
        val apiKeyPart = if (BuildConfig.MBTA_API_KEY.isBlank()) "" else (if ('?' in path) "&" else "?") + "api_key=${BuildConfig.MBTA_API_KEY}"
        val url = base + path + apiKeyPart
        val request = Request.Builder().url(url).header("Accept", "application/vnd.api+json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("MBTA API ${response.code}")
            return JSONObject(response.body?.string().orEmpty())
        }
    }
}
