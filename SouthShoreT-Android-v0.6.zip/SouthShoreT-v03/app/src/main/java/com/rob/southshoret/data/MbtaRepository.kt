package com.rob.southshoret.data

import com.rob.southshoret.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.time.Duration
import java.time.OffsetDateTime

data class Departure(val route: String, val destination: String, val minutes: Int, val mode: Mode)
data class StationBoard(val name: String, val departures: List<Departure>)
data class AlertItem(val header: String)
enum class Mode { RED, GREEN, BUS, COMMUTER }

class MbtaRepository {
    private val client = OkHttpClient()
    private val base = "https://api-v3.mbta.com"

    private val stations = linkedMapOf(
        "East Weymouth" to "place-GRB-0146",
        "Weymouth Landing" to "place-WML-0125",
        "Braintree" to "place-brntn",
        "Quincy Adams" to "place-qamnl",
        "Quincy Center" to "place-qnctr",
        "Park Street" to "place-pktrm"
    )

    suspend fun loadBoards(): List<StationBoard> = withContext(Dispatchers.IO) {
        val landingBus = weymouthLanding225Predictions()
        stations.map { (name, stopId) ->
            // Query child/platform stops as well as the parent station. This is important for
            // Green Line and Commuter Rail stations where predictions may live on platforms.
            val baseDepartures = when (name) {
                // Query the MBTA parent station directly. The predictions endpoint expands
                // parent stations to their boarding platforms; route filters keep each mode exact.
                "East Weymouth" -> greenbushPredictions("place-GRB-0146")
                "Weymouth Landing" -> greenbushPredictions("place-WML-0125")
                "Park Street" -> {
                    val red = predictionsFor("place-pktrm", "Red")
                    val green = parkStreetGreenPredictions()
                    red + green
                }
                else -> predictionsForStation(stopId)
            }
            val departures = when (name) {
                "Weymouth Landing" -> baseDepartures + landingBus
                else -> baseDepartures
            }
            StationBoard(name, departures.distinctBy { listOf(it.route, it.destination, it.minutes, it.mode) })
        }
    }

    suspend fun loadAllAlerts(): List<AlertItem> = withContext(Dispatchers.IO) {
        val root = getJson("/alerts?filter[activity]=BOARD,EXIT,RIDE")
        val data = root.optJSONArray("data") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until data.length()) {
                val attrs = data.getJSONObject(i).optJSONObject("attributes") ?: continue
                val header = attrs.optString("header").trim()
                if (header.isNotEmpty()) add(AlertItem(header))
            }
        }
    }

    private fun weymouthLanding225Predictions(): List<Departure> {
        val wanted = setOf("Quincy Ave @ Weymouth Landing", "Quincy Ave @ Commercial St")
        val stopsRoot = getJson("/stops?filter[route]=225")
        val data = stopsRoot.optJSONArray("data") ?: return emptyList()
        val stopIds = buildList {
            for (i in 0 until data.length()) {
                val stop = data.getJSONObject(i)
                val name = stop.optJSONObject("attributes")?.optString("name").orEmpty()
                if (name in wanted) add(stop.optString("id"))
            }
        }.filter { it.isNotBlank() }.distinct()

        return stopIds.flatMap { predictionsFor(it) }
            .filter { it.mode == Mode.BUS && it.route == "225" }
            .distinctBy { Triple(it.destination, it.minutes, it.route) }
            .sortedBy { it.minutes }
            .take(3)
    }



    private fun greenbushPredictions(parentId: String): List<Departure> {
        // Commuter Rail predictions are attached to boarding/platform stops, not reliably
        // to the parent place-* station. Discover the children first, then query Greenbush.
        val ids = childStopIds(parentId)
        return ids.flatMap { id ->
            runCatching { predictionsFor(id, "CR-Greenbush") }.getOrDefault(emptyList())
        }.filter { it.mode == Mode.COMMUTER }
            .distinctBy { listOf(it.route, it.destination, it.minutes) }
            .sortedBy { it.minutes }
            .take(3)
    }

    private fun parkStreetGreenPredictions(): List<Departure> {
        // Green Line predictions are likewise platform-level at Park Street. Discover all
        // Park Street child stops and query those for each Green branch.
        val ids = childStopIds("place-pktrm")
        return ids.flatMap { stopId ->
            listOf("Green-B", "Green-C", "Green-D", "Green-E").flatMap { routeId ->
                runCatching { predictionsFor(stopId, routeId) }.getOrDefault(emptyList())
            }
        }.filter { it.mode == Mode.GREEN }
            .distinctBy { listOf(it.route, it.destination, it.minutes) }
            .sortedBy { it.minutes }
            .take(6)
    }

    private fun childStopIds(parentId: String): List<String> {
        val root = getJson("/stops?filter[parent_station]=$parentId")
        val data = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (i in 0 until data.length()) {
                data.getJSONObject(i).optString("id").takeIf { it.isNotBlank() }?.let(::add)
            }
        }.distinct()
    }

    private fun predictionsForStops(stopIds: List<String>): List<Departure> =
        stopIds.flatMap { id -> runCatching { predictionsFor(id) }.getOrDefault(emptyList()) }
            .distinctBy { listOf(it.route, it.destination, it.minutes, it.mode) }
            .sortedBy { it.minutes }

    private fun predictionsForStation(parentId: String): List<Departure> {
        val ids = linkedSetOf(parentId)
        runCatching {
            val root = getJson("/stops?filter[parent_station]=$parentId")
            val data = root.optJSONArray("data")
            if (data != null) for (i in 0 until data.length()) {
                data.getJSONObject(i).optString("id").takeIf { it.isNotBlank() }?.let(ids::add)
            }
        }
        return ids.flatMap { predictionsFor(it) }
            .distinctBy { listOf(it.route, it.destination, it.minutes, it.mode) }
            .sortedBy { it.minutes }
    }

    private fun predictionsFor(stopId: String, routeFilter: String? = null): List<Departure> {
        val routePart = routeFilter?.let { "&filter[route]=$it" }.orEmpty()
        val root = getJson("/predictions?filter[stop]=$stopId$routePart&include=route,trip&sort=departure_time")
        val included = root.optJSONArray("included")
        val routeTypes = mutableMapOf<String, Int>()
        val tripHeadsigns = mutableMapOf<String, String>()
        if (included != null) for (i in 0 until included.length()) {
            val obj = included.getJSONObject(i)
            when (obj.optString("type")) {
                "route" -> routeTypes[obj.getString("id")] = obj.optJSONObject("attributes")?.optInt("type", -1) ?: -1
                "trip" -> tripHeadsigns[obj.getString("id")] = obj.optJSONObject("attributes")?.optString("headsign").orEmpty()
            }
        }
        val now = OffsetDateTime.now()
        val data = root.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<Departure>()
        for (i in 0 until data.length()) {
            val obj = data.getJSONObject(i)
            val attrs = obj.getJSONObject("attributes")
            val whenText = attrs.optString("departure_time").ifBlank { attrs.optString("arrival_time") }
            if (whenText.isBlank()) continue
            val event = runCatching { OffsetDateTime.parse(whenText) }.getOrNull() ?: continue
            val mins = Duration.between(now, event).toMinutes().coerceAtLeast(0).toInt()
            val rel = obj.getJSONObject("relationships")
            val routeId = rel.getJSONObject("route").optJSONObject("data")?.optString("id").orEmpty()
            val tripId = rel.getJSONObject("trip").optJSONObject("data")?.optString("id").orEmpty()
            val type = routeTypes[routeId] ?: -1
            val mode = when {
                routeId == "Red" -> Mode.RED
                routeId.startsWith("Green-") -> Mode.GREEN
                type == 3 -> Mode.BUS
                type == 2 -> Mode.COMMUTER
                else -> continue
            }
            val displayRoute = when (routeId) {
                "CR-Greenbush" -> "Greenbush"
                else -> routeId
            }
            out += Departure(displayRoute, tripHeadsigns[tripId].orEmpty().ifBlank { displayRoute }, mins, mode)
        }
        return out.take(12)
    }

    private fun getJson(path: String): JSONObject {
        val apiKeyPart = if (BuildConfig.MBTA_API_KEY.isBlank()) "" else (if ('?' in path) "&" else "?") + "api_key=${BuildConfig.MBTA_API_KEY}"
        val url = base + path + apiKeyPart
        val request = Request.Builder().url(url).header("Accept", "application/vnd.api+json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("MBTA API ${response.code}")
            return JSONObject(response.body?.string().orEmpty())
        }
    }
}
