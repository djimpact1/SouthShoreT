package com.rob.southshoret

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rob.southshoret.data.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterImmersiveMode()
        setContent { BoardApp() }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }
}

@Composable
fun BoardApp(repo: MbtaRepository = remember { MbtaRepository() }) {
    var boards by remember { mutableStateOf<List<StationBoard>>(emptyList()) }
    var alerts by remember { mutableStateOf<List<AlertItem>>(emptyList()) }
    var alertIndex by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                boards = repo.loadBoards()
                alerts = repo.loadAllAlerts()
                error = null
            } catch (t: Throwable) {
                error = t.message
            }
            delay(20_000)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1_000)
        }
    }
    LaunchedEffect(alerts, alertIndex) {
        if (alerts.isNotEmpty()) {
            val text = alerts.getOrNull(alertIndex)?.header.orEmpty()
            // Give longer alerts enough time to marquee fully before advancing.
            delay(maxOf(12_000L, text.length * 95L))
            alertIndex = (alertIndex + 1) % alerts.size
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            val names = listOf("East Weymouth", "Weymouth Landing", "Braintree", "Quincy Adams", "Quincy Center", "Park Street")
            names.forEach { name ->
                StationColumn(
                    boards.firstOrNull { it.name == name } ?: StationBoard(name, emptyList()),
                    Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
        Footer(now, alerts.getOrNull(alertIndex)?.header, error)
    }
}

@Composable
private fun StationColumn(board: StationBoard, modifier: Modifier) {
    Column(modifier.padding(horizontal = 4.dp).background(Color.Black)) {
        // Every station reserves exactly the same two-line header height so all mode rows align.
        Box(Modifier.fillMaxWidth().height(62.dp), contentAlignment = Alignment.TopStart) {
            Text(
                board.name.uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                lineHeight = 21.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
        }
        val grouped = board.departures.groupBy { it.mode }

        when (board.name) {
            "East Weymouth" -> {
                // Logo occupies the same two row slots used by Red Line + Bus elsewhere.
                Box(Modifier.weight(2f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(R.drawable.mbta_t_logo),
                        contentDescription = "MBTA T logo",
                        modifier = Modifier.fillMaxSize(0.68f),
                        contentScale = ContentScale.Fit
                    )
                }
                ModeBlock(Mode.COMMUTER, grouped[Mode.COMMUTER].orEmpty().take(3), Modifier.weight(1f))
            }
            "Park Street" -> {
                ModeBlock(Mode.RED, grouped[Mode.RED].orEmpty().take(3), Modifier.weight(1f))
                // Park Street has no bus panel: Green Line receives the full lower two-row area.
                ModeBlock(Mode.GREEN, grouped[Mode.GREEN].orEmpty().take(6), Modifier.weight(2f))
            }
            else -> {
                ModeBlock(Mode.RED, grouped[Mode.RED].orEmpty().take(3), Modifier.weight(1f))
                ModeBlock(Mode.BUS, grouped[Mode.BUS].orEmpty().take(3), Modifier.weight(1f))
                ModeBlock(Mode.COMMUTER, grouped[Mode.COMMUTER].orEmpty().take(3), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ModeBlock(mode: Mode, deps: List<Departure>, modifier: Modifier) {
    val (label, color) = when (mode) {
        Mode.RED -> "RED LINE" to Color(0xFFDA291C)
        Mode.GREEN -> "GREEN LINE" to Color(0xFF00843D)
        Mode.BUS -> "BUS" to Color(0xFFFFC72C)
        Mode.COMMUTER -> "COMMUTER RAIL" to Color(0xFF80276C)
    }
    Column(modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Box(Modifier.fillMaxWidth().background(color).padding(horizontal = 7.dp, vertical = 4.dp)) {
            Text(label, color = if (mode == Mode.BUS) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        if (deps.isEmpty()) Text("—", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(8.dp))
        deps.forEach { d ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (mode == Mode.BUS) "${d.route}  ${d.destination}" else d.destination,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                )
                Text(
                    if (d.minutes <= 0) "ARR" else "${d.minutes} MIN",
                    color = Color(0xFFFFD100),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun Footer(now: LocalDateTime, alert: String?, error: String?) {
    val date = now.format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy"))
    val time = now.format(DateTimeFormatter.ofPattern("h:mm:ss a"))
    val tickerText = error?.let { "DATA TEMPORARILY UNAVAILABLE" } ?: alert ?: "NO CURRENT SERVICE ALERTS"

    Row(
        Modifier.fillMaxWidth().height(44.dp).background(Color(0xFF171717)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("  $date   |   $time  ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Box(Modifier.background(Color(0xFFFFC72C)).padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("SERVICE ALERTS", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp)
        }
        Text(
            "     $tickerText     ",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            maxLines = 1,
            modifier = Modifier.weight(1f).basicMarquee(iterations = Int.MAX_VALUE)
        )
    }
}
