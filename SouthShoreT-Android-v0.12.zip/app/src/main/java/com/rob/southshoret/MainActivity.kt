package com.rob.southshoret

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rob.southshoret.data.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterImmersiveMode()
        setContent { BoardApp() }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }
}

@Composable
fun BoardApp(repo: MbtaRepository = remember { MbtaRepository() }) {
    var boards by remember { mutableStateOf<List<StationBoard>>(emptyList()) }
    var alerts by remember { mutableStateOf<List<AlertItem>>(emptyList()) }
    var alertIndex by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var boardError by remember { mutableStateOf<String?>(null) }
    var alertFetchSucceeded by remember { mutableStateOf(false) }

    // Arrival data and service alerts intentionally refresh on separate schedules. A failure in
    // either feed must never overwrite healthy data already on screen from the other feed.
    LaunchedEffect(Unit) {
        while (true) {
            try {
                boards = repo.loadBoards()
                boardError = null
            } catch (t: Throwable) {
                boardError = t.message
            }
            delay(20_000)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val freshAlerts = repo.loadAllAlerts()
                alerts = freshAlerts
                alertFetchSucceeded = true
                if (alertIndex !in freshAlerts.indices) alertIndex = 0
            } catch (_: Throwable) {
                // Keep the last successfully retrieved alerts. Do not turn an alert-only network
                // failure into a DATA TEMPORARILY UNAVAILABLE message.
            }
            delay(60_000)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1_000)
        }
    }
    LaunchedEffect(alerts, alertIndex) {
        if (alerts.isNotEmpty()) {
            val text = alerts.getOrNull(alertIndex)?.header.orEmpty()
            // Give longer alerts enough time to marquee fully before advancing.
            delay(maxOf(12_000L, text.length * 95L))
            alertIndex = (alertIndex + 1) % alerts.size
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            val names = listOf("East Weymouth", "Weymouth Landing", "Braintree", "Quincy Adams", "Quincy Center", "Park Street")
            names.forEach { name ->
                StationColumn(
                    boards.firstOrNull { it.name == name } ?: StationBoard(name, emptyList()),
                    Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
        Footer(now, alerts.getOrNull(alertIndex)?.header, alertFetchSucceeded)
    }
}

@Composable
private fun StationColumn(board: StationBoard, modifier: Modifier) {
    Column(modifier.padding(horizontal = 4.dp).background(Color.Black)) {
        // Every station reserves exactly the same two-line header height so all mode rows align.
        Box(Modifier.fillMaxWidth().height(62.dp), contentAlignment = Alignment.TopStart) {
            Text(
                board.name.uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                lineHeight = 21.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
        }
        val grouped = board.departures.groupBy { it.mode }

        when (board.name) {
            "East Weymouth" -> {
                // Logo occupies the same two row slots used by Red Line + Bus elsewhere.
                Box(Modifier.weight(2f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(R.drawable.mbta_t_logo),
                        contentDescription = "MBTA T logo",
                        modifier = Modifier.fillMaxSize(0.68f),
                        contentScale = ContentScale.Fit
                    )
                }
                ModeBlock(Mode.COMMUTER, grouped[Mode.COMMUTER].orEmpty().take(3), Modifier.weight(1f))
            }
            "Park Street" -> {
                // Park Street follows the same three equal service-band geometry as every station.
                // It simply has Red + Green, with no Bus or Commuter Rail section.
                ModeBlock(Mode.RED, grouped[Mode.RED].orEmpty().take(3), Modifier.weight(1f))
                ModeBlock(Mode.GREEN, grouped[Mode.GREEN].orEmpty().take(3), Modifier.weight(1f))
                Spacer(Modifier.weight(1f).fillMaxWidth())
            }
            "Weymouth Landing" -> {
                // Weymouth Landing has no Red Line. Reserve the same vertical slot invisibly so
                // its Bus and Commuter Rail panels remain aligned with every other station.
                Spacer(Modifier.weight(1f).fillMaxWidth())
                ModeBlock(Mode.BUS, grouped[Mode.BUS].orEmpty().take(3), Modifier.weight(1f))
                ModeBlock(Mode.COMMUTER, grouped[Mode.COMMUTER].orEmpty().take(3), Modifier.weight(1f))
            }
            else -> {
                ModeBlock(Mode.RED, grouped[Mode.RED].orEmpty().take(3), Modifier.weight(1f))
                ModeBlock(Mode.BUS, grouped[Mode.BUS].orEmpty().take(3), Modifier.weight(1f))
                ModeBlock(Mode.COMMUTER, grouped[Mode.COMMUTER].orEmpty().take(3), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ModeBlock(mode: Mode, deps: List<Departure>, modifier: Modifier) {
    val (label, color) = when (mode) {
        Mode.RED -> "RED LINE" to Color(0xFFDA291C)
        Mode.GREEN -> "GREEN LINE" to Color(0xFF00843D)
        Mode.BUS -> "BUS" to Color(0xFFFFC72C)
        Mode.COMMUTER -> "COMMUTER RAIL" to Color(0xFF80276C)
    }
    Column(modifier.fillMaxWidth().padding(bottom = 2.dp)) {
        Box(Modifier.fillMaxWidth().background(color).padding(horizontal = 7.dp, vertical = 3.dp)) {
            Text(label, color = if (mode == Mode.BUS) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        if (deps.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopStart) {
                Text("—", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
            }
        } else {
            // Exactly three equal arrival slots live inside every service band. The slot height is
            // calculated from the available band height, so a two-line destination never steals
            // space from the next arrival and a one-line destination never creates a taller row.
            repeat(3) { index ->
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                    deps.getOrNull(index)?.let { DepartureRow(mode, it) }
                }
            }
        }
    }
}

@Composable
private fun DepartureRow(mode: Mode, d: Departure) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (mode == Mode.BUS) {
            Text(
                d.route,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                modifier = Modifier.width(27.dp).padding(end = 2.dp)
            )
        }

        val raw = d.destination.replace(Regex("\\s+"), " ").trim()
        val display = readableDestination(raw)
        val twoLine = display.contains('\n')
        val destinationSize = if (twoLine) 10.5.sp else 12.sp
        val destinationLineHeight = if (twoLine) 10.5.sp else 12.sp

        Text(
            display,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = destinationSize,
            lineHeight = destinationLineHeight,
            maxLines = if (twoLine) 2 else 1,
            softWrap = false,
            overflow = TextOverflow.Clip,
            modifier = Modifier.weight(1f).padding(end = 2.dp)
        )
        Text(
            if (d.minutes <= 0) "ARR" else "${d.minutes} MIN",
            color = Color(0xFFFFD100),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
            textAlign = TextAlign.End,
            modifier = Modifier.widthIn(min = 38.dp)
        )
    }
}

// Produce at most two readable lines, breaking only at natural boundaries. We never insert a
// break inside a word and never use an ellipsis. Slash-separated destinations may break after '/'.
private fun readableDestination(destination: String): String {
    if (destination.length <= 11) return destination

    val slash = destination.indexOf('/')
    if (slash in 1 until destination.lastIndex) {
        return destination.substring(0, slash + 1) + "\n" + destination.substring(slash + 1).trimStart()
    }

    val spaces = destination.indices.filter { destination[it] == ' ' }
    if (spaces.isEmpty()) return destination
    val midpoint = destination.length / 2
    val split = spaces.minByOrNull { kotlin.math.abs(it - midpoint) } ?: return destination
    return destination.substring(0, split).trimEnd() + "\n" + destination.substring(split + 1).trimStart()
}

@Composable
private fun Footer(now: LocalDateTime, alert: String?, alertFetchSucceeded: Boolean) {
    val date = now.format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy"))
    val time = now.format(DateTimeFormatter.ofPattern("h:mm:ss a"))
    val tickerText = alert ?: if (alertFetchSucceeded) "NO CURRENT SERVICE ALERTS" else "SERVICE ALERTS CONNECTING…"

    Row(
        Modifier.fillMaxWidth().height(44.dp).background(Color(0xFF171717)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("  $date   |   $time  ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Box(Modifier.background(Color(0xFFFFC72C)).padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("SERVICE ALERTS", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp)
        }
        Text(
            "     $tickerText     ",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            maxLines = 1,
            modifier = Modifier.weight(1f).basicMarquee(iterations = Int.MAX_VALUE)
        )
    }
}
