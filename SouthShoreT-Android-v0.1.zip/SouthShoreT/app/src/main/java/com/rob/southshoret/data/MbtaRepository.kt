package com.rob.southshoret.data

import com.rob.southshoret.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.time.Duration
import java.time.OffsetDateTime

data class Departure(val route: String, val destination: String, val minutes: Int, val mode: Mode)
data class StationBoard(val name: String, val departures: List<Departure>)
data class AlertItem(val header: String)
enum class Mode { RED, GREEN, BUS, COMMUTER }

class MbtaRepository {
    private val client = OkHttpClient()
    private val base = "https://api-v3.mbta.com"

    // Parent/station stop IDs used by the MBTA API. Park Street is included for Red/Green service.
    private val stations = linkedMapOf(
        "Braintree" to "place-brntn",
        "Quincy Adams" to "place-qamnl",
        "Quincy Center" to "place-qnctr",
        "Weymouth Landing" to "place-WML-0125",
        "East Weymouth" to "place-WML-0158",
        "Park Street" to "place-pktrm"
    )

    suspend fun loadBoards(): List<StationBoard> = withContext(Dispatchers.IO) {
        stations.map { (name, stopId) -> StationBoard(name, predictionsFor(stopId)) }
    }

    suspend fun loadAllAlerts(): List<AlertItem> = withContext(Dispatchers.IO) {
        val root = getJson("/alerts?filter[activity]=BOARD,EXIT,RIDE")
        val data = root.optJSONArray("data") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until data.length()) {
                val attrs = data.getJSONObject(i).optJSONObject("attributes") ?: continue
                val header = attrs.optString("header").trim()
                if (header.isNotEmpty()) add(AlertItem(header))
            }
        }
    }

    private fun predictionsFor(stopId: String): List<Departure> {
        val root = getJson("/predictions?filter[stop]=$stopId&include=route,trip&sort=departure_time")
        val included = root.optJSONArray("included")
        val routeTypes = mutableMapOf<String, Int>()
        val tripHeadsigns = mutableMapOf<String, String>()
        if (included != null) for (i in 0 until included.length()) {
            val obj = included.getJSONObject(i)
            when (obj.optString("type")) {
                "route" -> routeTypes[obj.getString("id")] = obj.optJSONObject("attributes")?.optInt("type", -1) ?: -1
                "trip" -> tripHeadsigns[obj.getString("id")] = obj.optJSONObject("attributes")?.optString("headsign").orEmpty()
            }
        }
        val now = OffsetDateTime.now()
        val data = root.optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<Departure>()
        for (i in 0 until data.length()) {
            val obj = data.getJSONObject(i)
            val attrs = obj.getJSONObject("attributes")
            val whenText = attrs.optString("departure_time").ifBlank { attrs.optString("arrival_time") }
            if (whenText.isBlank()) continue
            val event = runCatching { OffsetDateTime.parse(whenText) }.getOrNull() ?: continue
            val mins = Duration.between(now, event).toMinutes().coerceAtLeast(0).toInt()
            val rel = obj.getJSONObject("relationships")
            val routeId = rel.getJSONObject("route").optJSONObject("data")?.optString("id").orEmpty()
            val tripId = rel.getJSONObject("trip").optJSONObject("data")?.optString("id").orEmpty()
            val type = routeTypes[routeId] ?: -1
            val mode = when {
                routeId == "Red" -> Mode.RED
                routeId.startsWith("Green-") -> Mode.GREEN
                type == 3 -> Mode.BUS
                type == 2 -> Mode.COMMUTER
                else -> continue
            }
            out += Departure(routeId, tripHeadsigns[tripId].orEmpty().ifBlank { routeId }, mins, mode)
        }
        return out.take(10)
    }

    private fun getJson(path: String): JSONObject {
        val url = base + path + if (BuildConfig.MBTA_API_KEY.isBlank()) "" else (if ('?' in path) "&" else "?") + "api_key=${BuildConfig.MBTA_API_KEY}"
        val request = Request.Builder().url(url).header("Accept", "application/vnd.api+json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("MBTA API ${response.code}")
            return JSONObject(response.body?.string().orEmpty())
        }
    }
}
